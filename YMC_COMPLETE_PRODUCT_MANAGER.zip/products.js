window.localProducts = [
  {id:"local-bag",name:"Elegant Women's Tote Bag",category:"bags",price:250,image:"images/elegant-womens-tote-bag.jpg",description:"Stylish and spacious tote bag with a sophisticated two-tone design, long shoulder straps, and elegant gold-tone detailing. Suitable for everyday use, work, shopping, and casual outings."}
];
