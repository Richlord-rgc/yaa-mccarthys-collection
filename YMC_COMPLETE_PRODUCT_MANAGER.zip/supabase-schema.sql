-- YMC PRODUCT CATALOGUE - run this once in Supabase SQL Editor
create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null check (category in ('bags','clothing','perfumes','shoes','jewellery','beauty')),
  price numeric(12,2) not null default 0,
  description text not null default '',
  image text not null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.products enable row level security;

drop policy if exists "Public can view active products" on public.products;
create policy "Public can view active products" on public.products
for select using (active = true);

drop policy if exists "Authenticated can insert products" on public.products;
create policy "Authenticated can insert products" on public.products
for insert to authenticated with check (true);

drop policy if exists "Authenticated can delete products" on public.products;
create policy "Authenticated can delete products" on public.products
for delete to authenticated using (true);

insert into public.products (name,category,price,description,image,active)
select 'Elegant Women''s Tote Bag','bags',250,
'Stylish and spacious tote bag with a sophisticated two-tone design, long shoulder straps, and elegant gold-tone detailing. Suitable for everyday use, work, shopping, and casual outings.',
'images/elegant-womens-tote-bag.jpg',true
where not exists (select 1 from public.products where name='Elegant Women''s Tote Bag');

insert into storage.buckets (id,name,public) values ('product-images','product-images',true)
on conflict (id) do nothing;

drop policy if exists "Public can view product images" on storage.objects;
create policy "Public can view product images" on storage.objects
for select using (bucket_id = 'product-images');

drop policy if exists "Authenticated can upload product images" on storage.objects;
create policy "Authenticated can upload product images" on storage.objects
for insert to authenticated with check (bucket_id = 'product-images');

drop policy if exists "Authenticated can delete product images" on storage.objects;
create policy "Authenticated can delete product images" on storage.objects
for delete to authenticated using (bucket_id = 'product-images');
