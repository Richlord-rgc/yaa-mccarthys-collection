// YMC Supabase configuration
// Paste your Supabase Project URL and anon/public key here.
// NEVER put a service_role key in this file.
window.SUPABASE_CONFIG = {
  url: "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE",
  anonKey: "PASTE_YOUR_SUPABASE_ANON_KEY_HERE"
};
