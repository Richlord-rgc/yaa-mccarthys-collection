const wa = "233550122057";
const grid = document.getElementById("products");
const statusEl = document.getElementById("status");
const buttons = document.querySelectorAll(".categories button");
let products = window.localProducts || [];
let currentCategory = "all";

function money(p){ return p && Number(p)>0 ? `GHS ${Number(p).toLocaleString()}` : "Price on WhatsApp"; }
function whatsapp(p){
  const price = Number(p.price)>0 ? ` — GHS ${p.price}` : "";
  const text = `Hello Yaa McCarthy's Collection, I'm interested in ${p.name}${price}. Please send me availability and details.`;
  return `https://wa.me/${wa}?text=${encodeURIComponent(text)}`;
}
function safe(s){ return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[c])); }
function render(category="all"){
  const list = category==="all" ? products : products.filter(p=>p.category===category);
  grid.innerHTML = list.length ? list.map(p=>`
    <article class="card">
      <div class="photo">${p.image ? `<img src="${safe(p.image)}" alt="${safe(p.name)}" loading="lazy">` : `<div class="placeholder">YMC<br><small>PRODUCT PHOTO</small></div>`}</div>
      <div class="info"><div class="tag">${safe(p.category)}</div><div class="name">${safe(p.name)}</div>
      <div class="desc">${safe(p.description)}</div><div class="price ${Number(p.price)>0?'':'contact-price'}">${money(p.price)}</div>
      <a class="order" href="${whatsapp(p)}" target="_blank" rel="noopener">ORDER ON WHATSAPP</a></div>
    </article>`).join("") : `<div class="empty">No products in this category yet.</div>`;
}
async function loadProducts(){
  const cfg=window.SUPABASE_CONFIG||{};
  if(!window.supabase || !cfg.url || cfg.url.includes("PASTE_")){ statusEl.textContent=""; render(currentCategory); return; }
  const client=window.supabase.createClient(cfg.url,cfg.anonKey);
  const {data,error}=await client.from("products").select("*").eq("active",true).order("created_at",{ascending:false});
  if(!error && data?.length){ products=data; } 
  else if(error){ console.warn(error); }
  statusEl.textContent="";
  render(currentCategory);
}
buttons.forEach(btn=>btn.addEventListener("click",()=>{buttons.forEach(b=>b.classList.remove("active"));btn.classList.add("active");currentCategory=btn.dataset.category;render(currentCategory);}));
loadProducts();
