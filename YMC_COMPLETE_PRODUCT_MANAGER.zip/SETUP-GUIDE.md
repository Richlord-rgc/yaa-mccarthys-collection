# YMC — One-place Product Manager

This version gives you:
- Public shop: `index.html`
- Owner product manager: `admin.html`
- Upload product photo
- Add name, category, GHS price and description
- Products are saved online in Supabase, so customers see updates without you editing HTML
- Existing tote bag is included as a local fallback

## One-time setup
1. Create a free Supabase project.
2. In Supabase, create an owner account under Authentication > Users (email/password).
3. Open SQL Editor and run `supabase-schema.sql`.
4. Open `supabase-config.js` and paste your Project URL and anon/public key from Project Settings > API.
5. Upload all files/folders in this package to your GitHub Pages repository.
6. Your public shop is your GitHub Pages URL.
7. Your private manager is the same URL plus `/admin.html`.
8. Log in at `/admin.html`, choose a photo, enter name/price/category/description, and tap Add Product.

IMPORTANT: Never put the Supabase service_role key in the website. Use only the anon/public key.
