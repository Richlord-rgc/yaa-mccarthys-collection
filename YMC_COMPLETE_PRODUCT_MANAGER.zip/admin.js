const cfg=window.SUPABASE_CONFIG||{};const loginCard=document.getElementById("loginCard"),app=document.getElementById("app");
if(!cfg.url||cfg.url.includes("PASTE_")){document.getElementById("loginMsg").textContent="First add your Supabase URL and anon key in supabase-config.js."; }
const sb=window.supabase.createClient(cfg.url,cfg.anonKey);
async function sessionCheck(){const {data}=await sb.auth.getSession();toggle(!!data.session);if(data.session)loadProducts();}
function toggle(on){loginCard.classList.toggle("hidden",on);app.classList.toggle("hidden",!on);}
document.getElementById("loginForm").addEventListener("submit",async e=>{e.preventDefault();const {error}=await sb.auth.signInWithPassword({email:email.value,password:password.value});document.getElementById("loginMsg").textContent=error?error.message:"";if(!error){toggle(true);loadProducts();}});
document.getElementById("logout").onclick=async()=>{await sb.auth.signOut();toggle(false)};
document.getElementById("productForm").addEventListener("submit",async e=>{e.preventDefault();const msg=document.getElementById("formMsg"),btn=document.getElementById("addBtn");btn.disabled=true;msg.textContent="Uploading…";
try{const file=document.getElementById("image").files[0];if(!file)throw Error("Choose an image.");const ext=(file.name.split(".").pop()||"jpg").toLowerCase();const path=`${crypto.randomUUID()}.${ext}`;
let up=await sb.storage.from("product-images").upload(path,file,{upsert:false,contentType:file.type});if(up.error)throw up.error;
const {data:urlData}=sb.storage.from("product-images").getPublicUrl(path);
const {error}=await sb.from("products").insert({name:name.value.trim(),category:category.value,price:Number(price.value),description:description.value.trim(),image:urlData.publicUrl,active:true});
if(error)throw error;msg.textContent="Product added successfully.";e.target.reset();loadProducts();}catch(err){msg.textContent=err.message||"Something went wrong."}finally{btn.disabled=false;}});
async function loadProducts(){const box=document.getElementById("productList");const {data,error}=await sb.from("products").select("*").order("created_at",{ascending:false});if(error){box.textContent=error.message;return}box.innerHTML=data.length?data.map(p=>`<div class="item"><img src="${p.image}" alt=""><div class="grow"><b>${escapeHtml(p.name)}</b><br>GHS ${Number(p.price).toLocaleString()} · ${escapeHtml(p.category)}</div><button class="danger" onclick="removeProduct('${p.id}')">Delete</button></div>`).join(""):"No products yet."}
async function removeProduct(id){if(!confirm("Delete this product?"))return;const {error}=await sb.from("products").delete().eq("id",id);if(error)alert(error.message);else loadProducts();}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[c]));}
sessionCheck();
